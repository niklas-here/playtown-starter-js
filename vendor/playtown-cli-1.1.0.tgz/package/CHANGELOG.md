`@playtown/cli` follows semantic versioning, like the SDK. Its commands, their options and the exit codes are what the versioning policy covers.

## 1.1.0 (29 October 2026)

### Added

- `playtown dev` shows the errors the game sends to its error log, in the log and under Checks.

## 1.0.1 (29 October 2026)

### Fixed

- `playtown dev` loads the game again. Since purchases came to the host, it stopped before the game started: the screen stayed black, and the console had an error about `{count}`.
- `playtown dev --help` shows the help instead of starting the host.
- The host's panels scroll on a small window instead of spilling over the edges, and the host says *loading* in English.

## 1.0.0 (29 October 2026)

The first stable version, together with the SDK's 1.0.0.

### Added

- `playtown dev` can try a child who may not play with others: `party.get()` answers `null` and `match.find()` is denied with `POLICY_DENIED`.
- `playtown dev` can lose the answer to a purchase: the purchase goes through, and the game gets `TIMEOUT`. Ask `commerce.entitlements()` to find it.

### Stable

- `playtown validate [folder]`: the same checks as PlayTown's import. Exit code 0 when the game passes, 1 when it does not.
- `playtown dev [folder]` with `--url`, `--port` and `--open`: the local PlayTown host.

## 0.1.0 (27 October 2026)

### Added

- The first version: `playtown validate` and `playtown dev`.
