# @playtown/cli

PlayTowns kommandorad för spelutvecklare.

```bash
npx playtown validate          # samma kontroller som PlayTowns import, på mappen med playtown.json
npx playtown dev               # kör den byggda exporten i en lokal PlayTown-värd
npx playtown dev --url http://localhost:5173   # eller din egen dev-server
```

`playtown dev` visar spelet i samma sandlåda och med samma brygga som i PlayTown. Där finns plattformsmenyn, sparningar med PlayTowns regler, en knapp som gör att nästa sparning krockar, och de händelser plattformen kan skicka: paus från en vuxen, tidsgräns, en annan enhet som tar över och byte av inmatning.

Dokumentationen finns på https://playtown-docs-staging.niklas-2d1.workers.dev
