# @playtown/cli

PlayTown's command line for game developers.

```bash
npx playtown validate          # the same checks as PlayTown's import, on the folder with playtown.json
npx playtown dev               # runs the built export in a local PlayTown host
npx playtown dev --url http://localhost:5173   # or your own dev server
```

`playtown dev` shows the game in the same sandbox and with the same bridge as in PlayTown. It has the platform menu, saves with PlayTown's rules, a button that makes the next save conflict, and the events the platform can send: a pause from an adult, a time limit, another device taking over and a change of input.

Every command prints in the terminal's language. Choose another one with `--lang`, for example `--lang en` or `--lang sv`.

The documentation is at https://playtown-docs-staging.niklas-2d1.workers.dev
