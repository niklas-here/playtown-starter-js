# @playtown/sdk

PlayTowns SDK för webbspel. Spelet ansluter till PlayTown, berättar när det är redo, sparar och tar emot pauser och inmatning genom SDK:n.

```ts
import { connect, createInput } from "@playtown/sdk";

const playtown = await connect();
playtown.on("session.suspend", () => pauseGame());
playtown.on("session.resume", () => resumeGame());

const save = await playtown.saves.get("progress");
await playtown.lifecycle.running();
```

Hela guiden, referensen och felkoderna finns i PlayTowns utvecklardokumentation: https://playtown-docs-staging.niklas-2d1.workers.dev

SDK:n har inga beroenden och väger ungefär 6 KB, eller 2,5 KB komprimerad.
