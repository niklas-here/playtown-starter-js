# @playtown/sdk

PlayTown's SDK for web games. Through the SDK the game connects to PlayTown, says when it is ready, saves, and receives pauses and input.

```ts
import { connect, createInput } from "@playtown/sdk";

const playtown = await connect();
playtown.on("session.suspend", () => pauseGame());
playtown.on("session.resume", () => resumeGame());

const save = await playtown.saves.get("progress");
await playtown.lifecycle.running();
```

The full guide, the reference and the error codes are in PlayTown's developer documentation: https://playtown-docs-staging.niklas-2d1.workers.dev

The SDK has no dependencies and weighs about 6 KB, or 2.5 KB compressed.
