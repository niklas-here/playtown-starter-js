`@playtown/sdk` follows semantic versioning. What a major, minor and patch version may change, and how long an old version keeps working, is in the developer documentation under *Versions and deprecation*.

## 1.0.1 (29 October 2026)

### Fixed

- WASD now works with Shift and Caps Lock too: `createInput` reads W and w as the same key.

## 1.0.0 (29 October 2026)

The first stable version. Everything below is covered by the versioning policy: it keeps working in every 1.x version.

### Stable

- `connect()`, `context`, `request()` and `on()`.
- Saving: `saves.get()` and `saves.put()` with revisions and `SAVE_CONFLICT`.
- The lifecycle: `lifecycle.running()`, `lifecycle.exit()`, and the events `session.suspend`, `session.resume` and `session.end`.
- PlayTown's menu and party panel: `ui.openMenu()` and `ui.openParty()`.
- Parties: `party.get()` and the event `party.changed`.
- Purchases: `commerce.requestPurchase()`, `commerce.entitlements()` and `commerce.consume()`.
- Matches: `match.find()`, `match.cancel()`, `match.send()`, `match.move()`, `match.finish()`, `match.leave()`, and the events `match.state` and `match.message`.
- Input: `createInput()` and the event `input.mode`.
- Errors: `PlayTownError` and the error codes.

### Changed

- Nothing in the API since 0.3.0. The version says that the API is now stable.

## 0.3.0 (28 October 2026)

### Added

- Purchases for Coins through PlayTown's own dialog: `commerce.requestPurchase()`, `commerce.entitlements()` and `commerce.consume()`.

## 0.2.0 (28 October 2026)

### Added

- Matches in PlayTown's match rooms: `match.*` and the events `match.state` and `match.message`.
- Parties: `party.get()`, `ui.openParty()` and the event `party.changed`.

## 0.1.0 (27 October 2026)

### Added

- The first version: `connect()`, saving, the lifecycle, PlayTown's menu and `createInput()`.
